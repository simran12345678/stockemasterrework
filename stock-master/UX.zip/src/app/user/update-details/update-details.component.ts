import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
