import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'update-ipo',
  templateUrl: './update-ipo.component.html',
  styleUrls: ['./update-ipo.component.css']
})
export class UpdateIpoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
