import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-company-search',
  templateUrl: './list-company-search.component.html',
  styleUrls: ['./list-company-search.component.css']
})
export class ListCompanySearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
